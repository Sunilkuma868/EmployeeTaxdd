package com.example.EmployeeTaxCalculator.controller;

import com.example.EmployeeTaxCalculator.model.Employee;
import com.example.EmployeeTaxCalculator.service.EmployeeService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import javax.validation.Valid;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/employees")
@Validated
public class EmployeeController {

    @Autowired
    private EmployeeService employeeService;

    @PostMapping
    public ResponseEntity<?> createEmployee(@Valid @RequestBody Employee employee) {
        try {
            Employee savedEmployee = employeeService.saveEmployee(employee);
            return new ResponseEntity<>(savedEmployee, HttpStatus.CREATED);
        } catch (Exception e) {
            Map<String, String> error = new HashMap<>();
            error.put("message", e.getMessage());
            return new ResponseEntity<>(error, HttpStatus.BAD_REQUEST);
        }
    }

    @GetMapping("/tax")
    public ResponseEntity<?> getTaxDeductions() {
        List<Employee> employees = employeeService.getAllEmployees();
        Map<String, Object> result = new HashMap<>();
        employees.forEach(employee -> {
            double tax = employeeService.calculateTax(employee);
            Map<String, Object> employeeTax = new HashMap<>();
            employeeTax.put("EmployeeId", employee.getEmployeeId());
            employeeTax.put("FirstName", employee.getFirstName());
            employeeTax.put("LastName", employee.getLastName());
            employeeTax.put("YearlySalary", employee.getSalary() * 12);
            employeeTax.put("TaxAmount", tax);
            result.put(employee.getEmployeeId(), employeeTax);
        });
        return new ResponseEntity<>(result, HttpStatus.OK);
    }
}
