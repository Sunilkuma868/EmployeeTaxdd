package com.example.EmployeeTaxCalculator.service;

import com.example.EmployeeTaxCalculator.model.Employee;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.List;

@Service
public class EmployeeService {

    private List<Employee> employees = new ArrayList<>();

    public Employee saveEmployee(Employee employee) {
        employees.add(employee);
        return employee;
    }

    public List<Employee> getAllEmployees() {
        return employees;
    }

    public double calculateTax(Employee employee) {
        LocalDate startOfFinancialYear = LocalDate.of(LocalDate.now().getYear(), 4, 1);
        LocalDate endOfFinancialYear = startOfFinancialYear.plusYears(1).minusDays(1);
        LocalDate doj = employee.getDateOfJoining();

        double monthlySalary = employee.getSalary();
        double yearlySalary = 0.0;
        if (doj.isBefore(startOfFinancialYear)) {
            yearlySalary = monthlySalary * 12;
        } else {
            long monthsWorked = ChronoUnit.MONTHS.between(doj, endOfFinancialYear) + 1;
            long daysWorked = ChronoUnit.DAYS.between(doj.withDayOfMonth(1), doj.plusMonths(1));
            double dailySalary = monthlySalary / 30;
            yearlySalary = (monthsWorked - 1) * monthlySalary + (30 - daysWorked) * dailySalary;
        }

        double tax = 0.0;
        double cess = 0.0;
        if (yearlySalary > 250000) {
            if (yearlySalary <= 500000) {
                tax = (yearlySalary - 250000) * 0.05;
            } else if (yearlySalary <= 1000000) {
                tax = 250000 * 0.05 + (yearlySalary - 500000) * 0.1;
            } else {
                tax = 250000 * 0.05 + 500000 * 0.1 + (yearlySalary - 1000000) * 0.2;
            }
        }

        if (yearlySalary > 2500000) {
            cess = (yearlySalary - 2500000) * 0.02;
        }
        return tax + cess;
    }
}
